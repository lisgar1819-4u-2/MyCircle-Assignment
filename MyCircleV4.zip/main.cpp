/***************************************************

Bin (Quoc Dat Phung)
Teacher: Ms. Lindsay Cullum
Date: March 27, 2019

        Program that uses CLASSES to print
        or manipulate info for the object
        MyCircle.
***************************************************/

#include <iostream>
using namespace std;
#include "apstring.h"
#include "apstring.cpp"
#include "MyCircle.h"

///Prototypes
void introduction();
void instanceMethods(MyCircle circle, MyCircle circle1, MyCircle circle2);
void compareObjects(MyCircle circle, MyCircle circle1, MyCircle circle2);
void infoString(MyCircle circle, MyCircle circle1, MyCircle circle2);
void staticMethods(MyCircle circle, MyCircle circle1, MyCircle circle2);

int main () {
    //Declaring option string
    apstring option;

    ///******************************************** INPUT
    MyCircle circle;
    circle.setRadius(3.00);
    circle.setUnits("cm");

    MyCircle circle1(1);
    MyCircle circle2(2.22, "m");


    ///******************************************** PROCESS
    //Instructions for user;
    introduction();

    while (option!= "q") {
        cout << endl << "Enter Option: ";
        cin >> option;

        if (option == "1") {
            ///Using Static Methods to print out info of MyCircle Objects
            staticMethods(circle, circle1, circle2);

        } else if (option == "2") {
            /// Return 1 if true (two different MyCircles are equal)
            /// Return 0 if not.
            compareObjects(circle, circle1, circle2);

        } else if (option == "3") {
            ///Use the printString() method to print out info of MyCircle Objects
            infoString(circle, circle1, circle2);

        } else if (option == "4") {
            ///use instance methods to print out info of MyCircle Objects.
            instanceMethods(circle, circle1, circle2);

        } else {
            cout << "Unknown option" << endl << endl;
        }
    }

    cout << endl << "End of Program..." << endl;
    return 0;
}

void introduction() {
    ///INSTRUCTIONS FOR USER
    cout << "Press 1:   Static Methods: getNumCircles(), getCircumference(double r), etc;" << endl;
    cout << "Press 2:    See if they are the same circles with bool equal(MyCircle c);" << endl;
    cout << "Press 3:    Prints out info (radius and units) with printString(); " << endl;
    cout << "Press 4:    Circles' Info with getRadius(), getUnits, getCircumference(), getArea()" << endl;
    cout << "Press q:    Quit Program. " << endl;
    cout << endl << "There are 3 circles in total." << endl;
}

void instanceMethods(MyCircle circle, MyCircle circle1, MyCircle circle2) {
    ///info of Circle
    cout << "Information about: Circle" << endl;
    cout << "Radius = " << circle.getRadius() << circle.getUnits() << endl;
    cout << "Diameter = " << circle.getDiameter() << circle.getUnits() << endl;
    cout << "Circumference = " << circle.getCircumference() << circle.getUnits() << endl;
    cout << "Area = " << circle.getArea() << circle.unitSquare() << endl << endl;

    ///info of Circle 1
    cout << "Information about: Circle1" << endl;
    cout << "Radius = " << circle1.getRadius() << " " << circle1.getUnits() <<endl;
    cout << "Diameter = " << circle1.getDiameter() << " " << circle1.getUnits() << endl;
    cout << "Circumference = " << circle1.getCircumference() << circle1.getUnits() << endl;
    cout << "Area = " << circle1.getArea() << circle1.unitSquare() << endl << endl;

    ///Info of Circle 2
    cout << "Information about: Circle2" << endl;
    cout << "Radius = " << circle2.getRadius() << circle2.getUnits() << endl;
    cout << "Diameter = " << circle2.getDiameter() << circle2.getUnits() << endl;
    cout << "Circumference = " << circle2.getCircumference() << circle2.getUnits() << endl;
    cout << "Area = " << circle2.getArea() << circle2.unitSquare() << endl << endl;
    cout << "_____________________" << endl;
}

void compareObjects(MyCircle circle, MyCircle circle1, MyCircle circle2) {
    ///Comparing objects to see if they are the same.
    cout << "Equal or not? --- True (1) and False(0) " << endl;
    cout << "Circle v.s Circle1: "<< circle.equals(circle1) << endl;
    cout << "Circle1 v.s Circle2: "<< circle1.equals(circle2) << endl << endl;
    cout << "_____________________" << endl;
}

void infoString(MyCircle circle, MyCircle circle1, MyCircle circle2) {
    ///Using printString() method.
    cout << endl << "CIRCLE: ";
    circle.printString();
    cout << endl << "CIRCLE1: ";
    circle1.printString();
    cout << endl << "CIRCLE2: ";
    circle2.printString();
    cout << endl;
    cout << "_____________________" << endl;
}

void staticMethods(MyCircle circle, MyCircle circle1, MyCircle circle2) {
    ///Using Static Methods...
    cout << "Number of Circle Objects is: " << circle.getNumCircles() << endl;
    cout << "Circle's new circumference (radius changed) is: " << circle.getCircumference(9.99) << " "
         << circle.getUnits() << endl;
    cout << "Circle's new area (radius changed) is: " << circle.getArea(9.99) << " "
         << circle.unitSquare() << endl << endl;
    cout << "_____________________" << endl;
}
