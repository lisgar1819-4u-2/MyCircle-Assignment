
#include "apstring.h"


class MyCircle {

  public:
    ///CONSTRUCTORS
    //overloading MyCircle
    MyCircle();
    MyCircle(double r, apstring u);
    MyCircle(double r);

    ///DECONSTRUCTOR
    ~MyCircle();

    /// INSTANCE METHODS
    void setRadius(double r);
    void setUnits(apstring s);
    double getRadius() const {
        return radius;
    };
    double getDiameter() const {
        return diameter;
    };
    apstring getUnits() const {
        return unit;
    };
    apstring unitSquare();
    double getCircumference();
    double getArea();
    bool equals(MyCircle c);
    void printString();

    /// STATIC METHODS
    static int getNumCircles();
    static double getCircumference(double r);
    static double getArea(double r);

  ///PRIVATE VARIABLES
  private:
    ///STATIC VARIABLES
    static double PI;
    static int numCircle;

    ///INSTANCE VARIABLES
    double radius;
    double diameter;
    apstring unit;

};
