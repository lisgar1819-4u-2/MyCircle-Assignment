

#include "MyCircle.h"
#include <cmath>

#include <iostream>
using namespace std;

double MyCircle::PI = 3.1415;
int MyCircle::numCircle = 0;


MyCircle::MyCircle() {
//Def of variables
    radius = 0;
    diameter = radius*2;
    unit = "unit";
    numCircle++;
}

MyCircle::MyCircle(double r, apstring u) {
    radius = r;
    diameter = r*2;
    unit = u;
    numCircle++;
}

MyCircle::MyCircle(double r) {
    radius = r;
    diameter = r*2;
    unit = "unit";
    numCircle++;
}

MyCircle::~MyCircle() {
    //an object is deleted
    numCircle--;
}



///METHODS
void MyCircle::setRadius(double r) {
    radius = r;
    diameter = r * 2;
}

void MyCircle::setUnits(apstring s) {
    unit = s;
}

apstring MyCircle::unitSquare() {
    apstring temp;
    temp = unit;
    temp += "^2";
    return temp;
}

double MyCircle::getCircumference() {
    return (2*PI*radius);
}

double MyCircle::getArea() {
    return (PI*radius*radius);
}

bool MyCircle::equals(MyCircle c) {
// Return 1 if true (two different MyCircles are equal)
// Return 0 if not.
    if (radius == c.radius) {
        if (unit == c.unit) {
            return true;
        }
    } else {
        return false;
    }
}

//+ printString(): void

void MyCircle::printString() {
//prints a string about specific info of MyCircle object
    cout << "radius = " << radius << unit << endl;
}

int MyCircle::getNumCircles() {
    return numCircle;
}

double MyCircle::getCircumference(double r) {
    return (2*PI*r);
}

double MyCircle::getArea(double r) {
    return (PI*r*r);
}
